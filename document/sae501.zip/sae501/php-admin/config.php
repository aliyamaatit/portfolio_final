<?php
/**
 * config.php
 * Connexion à la base MariaDB utilisée par FreeRADIUS
 * Utilisateur SQL : radius_app (droits limités)
 */

// Paramètres de connexion SQL
$DB_HOST = 'localhost';
$DB_NAME = 'radius';
$DB_USER = 'radius_user';
$DB_PASS = 'RadiusSQLStrongPwd!2026';

// DSN PDO
$dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4";

try {
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,      // erreurs explicites
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC // résultats en tableau associatif
    ]);
} catch (PDOException $e) {
    // En SAE on évite d'afficher les détails SQL
    http_response_code(500);
    exit("Erreur : connexion à la base RADIUS impossible.");
}

// Fonction d'échappement HTML (anti XSS)
function h(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

