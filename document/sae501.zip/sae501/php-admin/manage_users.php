<?php
session_start();
require_once __DIR__ . '/config.php';

if (empty($_SESSION['csrf'])) {
  $_SESSION['csrf'] = bin2hex(random_bytes(32));
}
if (empty($_SESSION['actor'])) {
  $_SESSION['actor'] = 'admin';
}

function csrf_check(): void {
  $t = $_POST['csrf'] ?? '';
  if (!hash_equals($_SESSION['csrf'], $t)) {
    http_response_code(403);
    exit("CSRF invalide.");
  }
}

function validate_username(string $u): bool {
  return (bool)preg_match('/^[a-zA-Z0-9._-]{3,32}$/', $u);
}
function validate_password(string $p): bool {
  return strlen($p) >= 8 && strlen($p) <= 72;
}

function audit(PDO $pdo, string $action, string $targetUser): void {
  $actor = $_SESSION['actor'] ?? 'admin';
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);

  $stmt = $pdo->prepare(
    "INSERT INTO admin_audit (actor, action, target_user, src_ip, user_agent)
     VALUES (?, ?, ?, ?, ?)"
  );
  $stmt->execute([$actor, $action, $targetUser, $ip, $ua]);
}

// ===== Actions =====
$msg = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_check();
  $action = $_POST['action'] ?? '';

  if ($action === 'set_actor') {
    $a = trim($_POST['actor'] ?? '');
    if ($a !== '' && preg_match('/^[a-zA-Z0-9._-]{3,32}$/', $a)) {
      $_SESSION['actor'] = $a;
      $msg = "Acteur défini : " . h($a);
    } else {
      $err = "Nom d'acteur invalide.";
    }
  }

  if ($action === 'add') {
    $u = trim($_POST['username'] ?? '');
    $p = trim($_POST['password'] ?? '');

    if (!validate_username($u)) $err = "Username invalide (3-32, lettres/chiffres . _ -).";
    elseif (!validate_password($p)) $err = "Mot de passe invalide (8-72 caractères).";
    else {
      // PEAP-MSCHAPv2 : FreeRADIUS a besoin du mot de passe en clair dans radcheck
      // (Cleartext-Password) pour vérifier MSCHAPv2 dans le tunnel PEAP.
      $stmt = $pdo->prepare(
        "INSERT INTO radcheck (username, attribute, op, value)
         VALUES (?, 'Cleartext-Password', ':=', ?)
         ON DUPLICATE KEY UPDATE value=VALUES(value)"
      );
      $stmt->execute([$u, $p]);

      audit($pdo, 'ADD', $u);
      $msg = "Utilisateur ajouté / mis à jour (PEAP-MSCHAPv2).";
    }
  }

  if ($action === 'delete') {
    $u = trim($_POST['username'] ?? '');

    if (!validate_username($u)) $err = "Username invalide.";
    else {
      $stmt = $pdo->prepare("DELETE FROM radcheck WHERE username = ?");
      $stmt->execute([$u]);

      // Optionnel : si vous utilisez radreply plus tard
      $stmt = $pdo->prepare("DELETE FROM radreply WHERE username = ?");
      $stmt->execute([$u]);

      audit($pdo, 'DELETE', $u);
      $msg = "Utilisateur supprimé.";
    }
  }
}

// ===== Listing (sans afficher les mots de passe) =====
$users = $pdo->query("SELECT id, username, attribute FROM radcheck ORDER BY username")->fetchAll();
$auditRows = $pdo->query("SELECT ts, actor, action, target_user, src_ip
                          FROM admin_audit ORDER BY ts DESC LIMIT 10")->fetchAll();

?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>RADIUS Admin — PEAP-MSCHAPv2</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: system-ui, Arial; margin: 22px; max-width: 1100px; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
    .card { border: 1px solid #ddd; border-radius: 12px; padding: 14px; }
    label { display:block; margin-top: 10px; margin-bottom: 6px; }
    input, button { width: 100%; padding: 8px; box-sizing: border-box; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    .ok { background:#f0fff0; border:1px solid #bfe8bf; padding:10px; border-radius:10px; }
    .ko { background:#fff0f0; border:1px solid #e8bfbf; padding:10px; border-radius:10px; }
    .hint { color:#444; font-size: .95em; }
  </style>
</head>
<body>

<h1>Interface PHP — gestion comptes RADIUS (PEAP-MSCHAPv2)</h1>
<p class="hint">
  Cette page gère <b>radcheck / Cleartext-Password</b> (nécessaire pour vérifier MSCHAPv2 dans le tunnel PEAP).
  Les mots de passe ne sont <b>jamais affichés</b>.
</p>

<?php if ($msg): ?><div class="ok"><?= h($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="ko"><?= h($err) ?></div><?php endif; ?>

<div class="grid">
  <div class="card">
    <h2>Ajouter / MAJ utilisateur</h2>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
      <input type="hidden" name="action" value="add">
      <label>Username</label>
      <input name="username" required placeholder="ex: user1">
      <label>Mot de passe</label>
      <input name="password" type="password" required placeholder="min 8 caractères">
      <br><br>
      <button type="submit">Ajouter / Mettre à jour</button>
    </form>
  </div>

  <div class="card">
    <h2>Supprimer utilisateur</h2>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
      <input type="hidden" name="action" value="delete">
      <label>Username</label>
      <input name="username" required placeholder="ex: user1">
      <br><br>
      <button type="submit">Supprimer</button>
    </form>

    <hr>

    <h2>Acteur (journal)</h2>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
      <input type="hidden" name="action" value="set_actor">
      <label>Nom admin</label>
      <input name="actor" value="<?= h($_SESSION['actor']) ?>">
      <br><br>
      <button type="submit">Définir</button>
    </form>
  </div>
</div>

<div class="card" style="margin-top:14px;">
  <h2>Comptes (radcheck)</h2>
  <table>
    <tr><th>ID</th><th>Username</th><th>Attribute</th></tr>
    <?php foreach ($users as $u): ?>
      <tr>
        <td><?= (int)$u['id'] ?></td>
        <td><?= h($u['username']) ?></td>
        <td><?= h($u['attribute']) ?></td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>

<div class="card" style="margin-top:14px;">
  <h2>Journal admin_audit (10 dernières actions)</h2>
  <table>
    <tr><th>Date</th><th>Actor</th><th>Action</th><th>Utilisateur</th><th>IP</th></tr>
    <?php foreach ($auditRows as $r): ?>
      <tr>
        <td><?= h($r['ts']) ?></td>
        <td><?= h($r['actor']) ?></td>
        <td><?= h($r['action']) ?></td>
        <td><?= h($r['target_user']) ?></td>
        <td><?= h($r['src_ip']) ?></td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>

</body>
</html>


