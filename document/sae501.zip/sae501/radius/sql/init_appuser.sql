CREATE USER 'radius_user'@'localhost'
IDENTIFIED BY 'RadiusSQLStrongPwd!2026';

GRANT SELECT, INSERT, UPDATE, DELETE
ON radius.*
TO 'radius_user'@'localhost';

FLUSH PRIVILEGES;
