USE radius;

CREATE TABLE radcheck (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(64) NOT NULL,
  attribute VARCHAR(64) NOT NULL,
  op CHAR(2) NOT NULL DEFAULT ':=',
  value VARCHAR(253) NOT NULL
);

CREATE TABLE radreply (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(64) NOT NULL,
  attribute VARCHAR(64) NOT NULL,
  op CHAR(2) NOT NULL DEFAULT '=',
  value VARCHAR(253) NOT NULL
);

CREATE TABLE radusergroup (
  username VARCHAR(64) NOT NULL,
  groupname VARCHAR(64) NOT NULL,
  priority INT NOT NULL DEFAULT 1,
  PRIMARY KEY (username, groupname)
);

CREATE TABLE radgroupreply (
  id INT AUTO_INCREMENT PRIMARY KEY,
  groupname VARCHAR(64) NOT NULL,
  attribute VARCHAR(64) NOT NULL,
  op CHAR(2) NOT NULL DEFAULT '=',
  value VARCHAR(253) NOT NULL
);

CREATE TABLE radacct (
  radacctid BIGINT AUTO_INCREMENT PRIMARY KEY,
  acctsessionid VARCHAR(64),
  username VARCHAR(64),
  nasipaddress VARCHAR(15),
  framedipaddress VARCHAR(15),
  acctstarttime DATETIME,
  acctstoptime DATETIME,
  acctsessiontime INT,
  callingstationid VARCHAR(50),
  framedprotocol VARCHAR(20)
);

CREATE TABLE radpostauth (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(64),
  pass VARCHAR(64),
  reply VARCHAR(32),
  authdate DATETIME
);

