#!/bin/bash

echo "[+] Installation MariaDB"
apt update
apt install -y mariadb-server mariadb-client

systemctl enable mariadb
systemctl start mariadb

echo "[+] MariaDB installé et démarré"
