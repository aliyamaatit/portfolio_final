#!/bin/bash

echo "[+] Prepa FreeRADIUS"
sudo apt update
sudo apt install -y freeradius freeradius-mysql

