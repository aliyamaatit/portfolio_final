#!/bin/bash

echo "Diagnostic serveur"
hostnamectl
ip a
ip route
ss -tulpen
df -h
uptime
